	/*  1- Print your name and ID on the same line.
	    2- Print your department on a separate line. */


public class Ex1
{


	public static void main(String[] args)
	{

	// 1-
		System.out.print("\nAbobaker Ahmed Khidir Hassan");
		System.out.println(" - 21-304.");

	// 2-
		System.out.print("Computer Sciences.\n");

	}

}