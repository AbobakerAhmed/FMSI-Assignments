// Name: Abobaker Ahmed Khidir Hassan.
//ID:    21-304
//D:     Computer Sciences

import java.util.*;
 
public class Ex2{

	
	
	public static void main(String args[]){

	Scanner input = new Scanner(System.in);
	double num1=0;
	double num2=0;

	System.out.print("What is the first number? ");
	num1= input.nextDouble();
	
	System.out.print("What is the second number? ");
	num2=input.nextDouble();	
	

	System.out.println("num1 + num2 = " + (num1 + num2) + ".");
	System.out.println("num1 - num2 = " + (num1 - num2) + ".");
	System.out.println("num1 * num2 = " + (num1 * num2) + ".");
	System.out.println("num1 / num2 = " + (num1 / num2) + ".");

	}


}