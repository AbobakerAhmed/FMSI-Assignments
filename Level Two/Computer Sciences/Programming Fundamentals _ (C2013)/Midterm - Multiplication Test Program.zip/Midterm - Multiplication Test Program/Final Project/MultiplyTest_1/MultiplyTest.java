// Project 1: MultiplyTest.java
// Test application for class Multiply
// Date: 20th of June 2024

//Name: Abobaker Ahmed Khidir Hassan
//ID:   21-304
//D:    Computer Science


public class MultiplyTest
{
	// main method
	public static void main( String args[] )
	{
		Multiply application = new Multiply(); // creating an object from Multiply class.
		application.quiz();	// calling quiz method from Multiply class.

	} // end main

} // end class MultiplyTest