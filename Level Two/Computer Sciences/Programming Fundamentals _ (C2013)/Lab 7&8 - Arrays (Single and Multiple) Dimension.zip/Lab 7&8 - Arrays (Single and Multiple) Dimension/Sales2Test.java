// Debugging Problem Chapter 7: Sales2Test.java
// Test application for class Sales2

public class Sales2Test
{
	public static void main( String args[] )
	{
		Sales2 application = new Sales2();
		application.calculateSales();
	} // end main

} // end class Sales2Test